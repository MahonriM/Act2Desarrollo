﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using MvcEmpresaMun.Utilerias;

namespace MvcConRepo.Models
{
    public class EmpresaRepositorio : IEmpresa
    {

        public List<Empresa> obtenerEmpresas()
        {
            List<Empresa> lstEmpresas = new List<Empresa>();
            DataTable dtEmpresas = new DataTable();

            dtEmpresas = BaseHelper.ejecutarSelect("spEmpresaConsultarTodo", CommandType.StoredProcedure);

            for (int i = 0; i < dtEmpresas.Rows.Count; i++)
            {
                Empresa empTemp = new Empresa();
                empTemp.IdEmpresa = int.Parse(dtEmpresas.Rows[i]["idEmpresa"].ToString());
                empTemp.Nombre = dtEmpresas.Rows[i]["nombre"].ToString();
                empTemp.Direccion = dtEmpresas.Rows[i]["direccion"].ToString();
                empTemp.Telefono = dtEmpresas.Rows[i]["telefono"].ToString();
                lstEmpresas.Add(empTemp);
            }
            return lstEmpresas;
        }

        public Empresa obtenerEmpresa(int idEmpresa)
        {
            Empresa empresa;
            DataTable dtEmpresas = new DataTable();
            List<SqlParameter> parametros = new List<SqlParameter>();

            parametros.Add(new SqlParameter("@idEmpresa", idEmpresa));
            dtEmpresas = BaseHelper.ejecutarSelect("spEmpresaConsultarPorID", CommandType.StoredProcedure, parametros);
            if (dtEmpresas.Rows.Count > 0)
            {
                empresa = new Empresa();
                empresa.IdEmpresa = int.Parse(dtEmpresas.Rows[0]["idEmpresa"].ToString());
                empresa.Nombre = dtEmpresas.Rows[0]["nombre"].ToString();
                empresa.Direccion = dtEmpresas.Rows[0]["direccion"].ToString();
                empresa.Telefono = dtEmpresas.Rows[0]["telefono"].ToString();
                empresa.idMunicipio= int.Parse(dtEmpresas.Rows[0]["idMunicipio"].ToString());
                return empresa;
            }
            else
            {

                return null;
            }
        }

        public void insertarEmpresa(Empresa datosAInsertar)
        {
            List<SqlParameter> parametros = new List<SqlParameter>();

            parametros.Add(new SqlParameter("@idEmpresa", datosAInsertar.IdEmpresa));
            parametros.Add(new SqlParameter("@nombre", datosAInsertar.Nombre));
            parametros.Add(new SqlParameter("@direccion", datosAInsertar.Direccion));
            parametros.Add(new SqlParameter("@telefono", datosAInsertar.Telefono));
            parametros.Add(new SqlParameter("@idMunicipio", datosAInsertar.idMunicipio));
            BaseHelper.ejecutarSentencia("spEmpresaInsertar", CommandType.StoredProcedure, parametros);
            
        }

        public void eliminarEmpresa(int idEmpresa)
        {
            List<SqlParameter> parametros = new List<SqlParameter>();

            parametros.Add(new SqlParameter("@idEmpresa", idEmpresa));

            BaseHelper.ejecutarSentencia("spEmpresaEliminar", CommandType.StoredProcedure, parametros);
        }

        public void actualizarEmpresa(Empresa datosNuevos)
        {
            List<SqlParameter> parametros = new List<SqlParameter>();

            
            parametros.Add(new SqlParameter("@nombre", datosNuevos.Nombre));
            parametros.Add(new SqlParameter("@direccion", datosNuevos.Direccion));
            parametros.Add(new SqlParameter("@telefono", datosNuevos.Telefono));
            parametros.Add(new SqlParameter("@idEmpresa", datosNuevos.IdEmpresa));
            parametros.Add(new SqlParameter("@idMunicipio", datosNuevos.idMunicipio));
            BaseHelper.ejecutarSentencia("spEmpresaModificar", CommandType.StoredProcedure, parametros);
        }
    }
}