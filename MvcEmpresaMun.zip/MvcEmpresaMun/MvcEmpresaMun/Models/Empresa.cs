﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcConRepo.Models
{
    public class Empresa
    {
        public int IdEmpresa { get; set; }
        public string Nombre { get; set; }
        public string Direccion { get; set; }
        public string Telefono { get; set; }
        public int idMunicipio { get; set;}
    }
}