﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using MvcEmpresaMun.Utilerias;

namespace MvcConRepo.Models
{
    public class MunicipioRepositorio : IMunicipio
    {

        public List<Municipio> obtenerMunicipios()
        {
            List<Municipio> lstMunicipios = new List<Municipio>();
            DataTable dtMunicipios = new DataTable();

            dtMunicipios = BaseHelper.ejecutarSelect("spMunicipioConsultarTodo", CommandType.StoredProcedure);

            for (int i = 0; i < dtMunicipios.Rows.Count; i++)
            {
                Municipio empTemp = new Municipio();
                empTemp.IdMunicipio = int.Parse(dtMunicipios.Rows[i]["idMunicipio"].ToString());
                empTemp.Nombre = dtMunicipios.Rows[i]["nombre"].ToString();
                lstMunicipios.Add(empTemp);
            }
            return lstMunicipios;
        }

        public Municipio obtenerMunicipio(int idMunicipio)
        {
            Municipio Municipio;
            DataTable dtMunicipios = new DataTable();
            List<SqlParameter> parametros = new List<SqlParameter>();

            parametros.Add(new SqlParameter("@idMunicipio", idMunicipio));
            dtMunicipios = BaseHelper.ejecutarSelect("spMunicipioConsultarPorID", CommandType.StoredProcedure, parametros);
            if (dtMunicipios.Rows.Count > 0)
            {
                Municipio = new Municipio();
                Municipio.IdMunicipio = int.Parse(dtMunicipios.Rows[0]["idMunicipio"].ToString());
                Municipio.Nombre = dtMunicipios.Rows[0]["nombre"].ToString();
                return Municipio;
            }
            else
            {

                return null;
            }
        }

        public void insertarMunicipio(Municipio datosAInsertar)
        {
            List<SqlParameter> parametros = new List<SqlParameter>();

            parametros.Add(new SqlParameter("@idMunicipio", datosAInsertar.IdMunicipio));
            parametros.Add(new SqlParameter("@nombre", datosAInsertar.Nombre));
       
            BaseHelper.ejecutarSentencia("spMunicipioInsertar", CommandType.StoredProcedure, parametros);
            
        }

        public void eliminarMunicipio(int idMunicipio)
        {
            List<SqlParameter> parametros = new List<SqlParameter>();

            parametros.Add(new SqlParameter("@idMunicipio", idMunicipio));

            BaseHelper.ejecutarSentencia("spMunicipioEliminar", CommandType.StoredProcedure, parametros);
        }

        public void actualizarMunicipio(Municipio datosNuevos)
        {
            List<SqlParameter> parametros = new List<SqlParameter>();

            
            parametros.Add(new SqlParameter("@nombre", datosNuevos.Nombre));
            parametros.Add(new SqlParameter("@idMunicipio", datosNuevos.IdMunicipio));

            BaseHelper.ejecutarSentencia("spMunicipioModificar", CommandType.StoredProcedure, parametros);
        }
    }
}