﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcConRepo.Models
{
    public interface IEmpresa
    {
        List<Empresa> obtenerEmpresas();
        Empresa obtenerEmpresa(int idEmpresa);
        void insertarEmpresa(Empresa datosAInsertar);
        void eliminarEmpresa(int idEmpresa);
        void actualizarEmpresa(Empresa datosNuevos);
    }
}