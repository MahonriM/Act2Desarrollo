﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcConRepo.Models
{
    public interface IMunicipio
    {
        List<Municipio> obtenerMunicipios();
        Municipio obtenerMunicipio(int idMunicipio);
        void insertarMunicipio(Municipio datosAInsertar);
        void eliminarMunicipio(int idMunicipio);
        void actualizarMunicipio(Municipio datosNuevos);
    }
}